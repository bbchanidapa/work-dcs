<?
session_start();

$name = $_POST['name'];
$password = $_POST['password'];
$link = mysql_connect("localhost","root","1234");
//check error connect DB
	if (!$link ) {
		die(mysql_error());
	}
//check error  DB
	$sql = mysql_select_db('session_test');
	if (!$sql) {
		echo "DB error";
	}
//
	$sql = "select * from user";
	$result = mysql_query($sql);
	while ($col = mysql_fetch_array($result)) {
		if ($col[0]==$name && $col[1]) {
			$_SESSION['name']=$name;
			$_SESSION['password']= $password;
			$valid = 'yes';
			break;
		}else{
			$valid = 'no';
		}
	}
	if ($valid=='yes') {?>
		<script type="text/javascript">
			window.location = 'home.php';
		</script>
	<?}else{
		session_destroy();
		?>
			<script type="text/javascript">
				window.location = 'index.php';
			</script>
		<?
	}
	mysql_close($link);
?>