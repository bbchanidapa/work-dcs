<?
	session_start();
	if ($_SESSION['login'=='yes']) {
		?>
		<html>
		<head>
			<meta charset="UTF-8">
		</head>
		
		<body>
			<table width="80%">
				<form method="post" action="logout.php" >
						<tr>
							<td><input type="submit" value="ออกจากระบบ"></input></td>
						</tr>
				</form>
			</table>
		</body><?

	}else{ 
	?>
		<body>
		<meta charset="UTF-8">
		
				<form method="post" action="login.php"  >
					<table>
						<tr>
					<td align="right">ชื่อ :</td>
						<td><input type="text" name="name" size="20"></input></td>
					</tr>
					<tr>
					<td align="right">รหัสผ่าน :</td>
						<td><input type="password" name="password" size="20"></input></td>
					</tr>
					<tr>
						<td><input type="submit" value="เข้าสู่ระบบ"></input></td>
						<td><input type="reset" value="ล้างข้อมูล"></input> <a href="signin_form.php">สมัครสมาชิก</a></td>
					</tr>

					</table>
				</form>
				<!--
				<form>
					<table method="post" action= "signin_from.php">
						<tr>
							<td>สมัครสมาชิกใหม่</td>
						</tr>
					</table>
				</form>
			-->
		</body>
	<?

	}
?>