<?
//$mount = time()+2592000; //2592000 เวลาหนึ่งเดือน
$time_now = date("F JS, Y -g:i a");
setcookie(LastVisit, $time_now, $month);
echo "$time_now";


if ($COOKIE['LastVisit']) {
	$last = $_COOKIE['LastVisit'];
	$mount = time()+2592000;
	setcookie(LastVisit, $time_now, $month);
	echo $last;
}else{
	echo "Welcome";
}
echo "Hi...........";
echo "Today is $time_now";
?>