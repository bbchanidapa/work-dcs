<?
session_start();
	if (isset($_SESSION['name'])) {
		include('header.php');
		?>

			<html>
			<head>
				<title>Home</title>
				<meta charset="UTF-8">
			</head>
			<body align="center">
			<br><br>
			<b>Welcome... User :</b>
			
				<? echo $_SESSION['name'];//show user จาก DB ?>
				<br><? 
				include('product.php');?>
			</body>
			</html>
		<?

	}else{
		?>
			<script type="text/javascript">
				window.location = 'index.php';
			</script>
		<?
	}
?>